	$(document).ready(function() {

		$('h4 a').each(function() {
			var $dialog = $('<div></div>')
			var $link = $(this).one('click', function() {
				$dialog
					.load($link.attr('href') + ' #content')
					.dialog({
						title: $link.attr('title'),
						width: 400,
						height: 500
					});

				$link.click(function() {
					$dialog.dialog('open');

					return false;
				});

				return false;
			});
		});
	});