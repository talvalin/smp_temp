/**
 * Created by PyCharm.
 * User: Lal
 * Date: 20/12/2011
 * Time: 02:56
 * To change this template use File | Settings | File Templates.
 */
//Clickable Boxes
$(document).ready(function(){

    $("#liststack").click(function(){
        window.location=$(this).find("a").attr("href");return false;
    });

});

//On Hover
$('.onhover').hover(
    function(){ $(this).addClass('hover_style_class') },
    function(){ $(this).removeClass('hover_style_class') }
);